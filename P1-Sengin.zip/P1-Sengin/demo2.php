<?php
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
  
  <link href=" bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="font/css/all.css" rel="stylesheet">
  <script src="bootstrap/js/bootstrap.min.js"></script>
               
               
                <style>
                           body
                   {
                   max-width: 100%;
                   overflow-x: hidden; 

                    }  

                    .card
                      {
                        margin-left: 100px; 
                          margin-top: 40px;
                          margin-right: 40px;
                      }
                    
                    
                    
                    body
                    {
                        margin: 0;
                        padding: 0;
                        background: #262662;
                    }
                    
                    ul
                    {
                        margin: 0;
                        padding: 0;
                        display:inline-flex;
                        position: absolute;
                        top:50%;
                        left: 50%;
                        transform : translate(-50%, -50%);
                    }
                    
                    ul li
                    {
                        list-style: none;
                        margin: 0 15px;
                    }
                    
                    ul li a
                    {
                        position: relative;
                        display: block;
                        width: 60px;
                        height: 60px;
                        text-align: center;
                        line-height: 60px;
                        background: #333;
                        border-radius: 20%;
                        font-size: 30px;
                        color: #666;
                        transition: .5s;
                    }
                    
                    ul li a:before
                    {
                        content: '';
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        border-radius: 20%;
                        background: #ffee10;
                        
                        
                
                    
                   
                        transition: .5s;
                        transform: scale(.9);
                    
                        z-index: -1;
                    
                    }
                    
                
                    ul li a:hover:before
                    {
                      transform: scale(1.1);
                        box-shadow: 0 0 15px #ffee10;
                        
                        
                    }
                    
                    ul li a:hover
                    {
                        color: #ffee10;
                        box-shadow: 0 0 5px #ffee10;
                        text-shadow: 0 0 5px #ffee10;
                    }

*/
                        </style>
                        
    <!-- ------------------------------------------- -->                    
                        
    ?> 
       
  </head>
  <body>
          
    <!-- -----------------------------nav--------------------------- -->
   
   
   <!-- nav  ------------------------------------------------------------------- -->
   
 
    
    <!-- ---------------------------caro ----------------------------- -->
         
    <!-- ----------------------------------------------------------------------------------- -->
    
      
        
        
        <!-- --------------------------------------------------------------------------------- -->
       
           
        
 <!-- ------------------------------------img res --------------------------------------------- -->    
                           
  
  
</footer>   
    


         

</html>



        
      
       
        